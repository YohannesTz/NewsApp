package com.yohannes.app.dev.newsapp.models;

/**
 * Created by Yohannes on 26-Mar-20.
 */

public interface OnLoadMoreListener {
    void onLoadMore();
}
