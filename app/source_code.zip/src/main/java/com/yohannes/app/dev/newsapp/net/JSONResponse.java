package com.yohannes.app.dev.newsapp.net;

import com.yohannes.app.dev.newsapp.models.News;

/**
 * Created by Yohannes on 30-Mar-20.
 */

public class JSONResponse {
    private News[] newsArray;

    public News[] getNewsArray() {
        return newsArray;
    }
}
