package com.yohannes.app.dev.newsapp.models;

/**
 * Created by Yohannes on 29-Mar-20.
 */

public class HttpHandler {

}
